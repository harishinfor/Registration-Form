import { Component, OnInit } from '@angular/core';
import {  ElementRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';


interface IData{
  userid:string;
  user:string;
  password:string;
  course:string;
  city:string;
  state:string;
  country:string;
}
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  data:IData;
  userid:string;
  user:string;
  password:string;
  course:string;
  city:string;
  state:string;
  country:string;

  
constructor(private router:Router, private route:ActivatedRoute){
}

ngOnInit():void{

}

  onSubmit(form:NgForm):void {
    this.data = {
      userid:form.value.userid,
      user:form.value.user,
      password:form.value.password,
      course:form.value.course,
      city:form.value.city,
      state:form.value.state,
      country:form.value.country
    }
    this.router.navigateByUrl('/dashboard', {state:this.data});
  }
}

