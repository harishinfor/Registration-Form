import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/Auth/auth-guard.service';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RegistrationComponent } from './registration/registration.component';

const routes: Routes = [
  {path:"", component:RegistrationComponent},
  {path:"registration", component:RegistrationComponent},
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [ AuthGuard ]
}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations:[DashboardComponent],
  providers: [ AuthGuard ]
})
export class AppRoutingModule { }
