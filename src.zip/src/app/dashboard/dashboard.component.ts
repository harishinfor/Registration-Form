import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  data:any;
  userid:string;
  user:string;
  password:string;
  course:string;
  city:string;
  state:string;
  country:string;

  constructor() { }

  ngOnInit() {
    this.data = history.state;
    this.userid = this.data.userid;
    this.user = this.data.user;
    this.password = this.data.password;
    this.course = this.data.course;
    this.city = this.data.city;
    this.state = this.data.state;
    this.country = this.data.country;
  }

}
