import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable,of } from 'rxjs';
import { AuthService } from './auth.service';
import { catchError, map } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class AuthGuard implements CanActivate {
    constructor(private authService: AuthService, private router: Router) { } 
    
    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean> | boolean {
        if (this.authService.isAuthenticated) {
            this.router.navigate(['/dashboard']);
            // this.authService.isAuthenticated= false;
            return true;
        }
    
        // navigate to login page
        this.router.navigate(['/registration']);
        // you can save redirect url so after authing we can move them back to the page they requested
        return false;
    }
    
   
}