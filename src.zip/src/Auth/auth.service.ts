
import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
})
export class AuthService {

    // Assumption of calling API Endpoint
    // isAuthenticated():boolean {
    //     return true;
    // }
    isAuthenticated: boolean = true;
}; 